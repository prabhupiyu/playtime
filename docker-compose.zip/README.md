## Run marbles using docker-compose
```
docker-compose -f docker-compose-no-cdb.yml -f marbles.yml up -d cop-01 orderer-01 peer-01
docker-compose -f docker-compose-no-cdb.yml -f marbles.yml up -d peer-02 mtc-01
docker-compose -f docker-compose-no-cdb.yml -f marbles.yml up -d peer-03 mtc-02
```

Go to `localhost:3000` for United Marbles UI
Go to `localhost:3001` for Marble Market UI

## Delete everything
docker-compose -f docker-compose-no-cdb.yml -f marbles.yml down

